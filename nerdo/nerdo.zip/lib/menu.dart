import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nerdo/home.dart';
import 'ContactUs.dart';
import 'Settings.dart';

class Menu extends StatefulWidget {
  @override
  State<Menu> createState() => _MenuState();
}

void _goToHome(BuildContext ctx) {
  Navigator.of(ctx).push(
    MaterialPageRoute(builder: (_) {
      return Home();
    }),
  );
}

void _goToSettings(BuildContext ctx) {
  Navigator.of(ctx).push(
    MaterialPageRoute(builder: (_) {
      return Settings();
    }),
  );
}

void _goContactUs(BuildContext ctx) {
  Navigator.of(ctx).push(
    MaterialPageRoute(builder: (_) {
      return ContactUS();
    }),
  );
}

class _MenuState extends State<Menu> {
  bool _usernameIsEntered = false;
  bool _passwordIsEntered = false;
  String _username = '';
  String _password = '';

  double screenWidth = 0;
  double screenHeight = 0;

  final String title = "Rakeny";

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          UserAccountsDrawerHeader(
            decoration: const BoxDecoration(
              color: Color(0xFFf8b323),
              image: DecorationImage(
                fit: BoxFit.fill,
                image: AssetImage(
                  'images/cover_image_sidebar.jpg',
                ), //Cover Image
              ),
            ),
            onDetailsPressed: () {
              //_goToUserProfile(context);
            },
            accountName: const Text(
              "Nardine",
              style: TextStyle(
                fontSize: 18,
              ),
            ),
            accountEmail: const Text(
              '@' + 'nardine123',
            ),
            currentAccountPicture: CircleAvatar(
              child: ClipOval(
                child: Image.asset(
                  'images/user_icon.png',
                  fit: BoxFit.fill,
                ),
                // child: Image.network(
                //   userImage,
                //   fit: BoxFit.fill,
                // ),
              ),
            ),
          ),
          /**********************/
          // const DrawerHeader(
          //   decoration: BoxDecoration(
          //     color: Colors.orangeAccent,
          //   ),
          //   child: Text('Profile'), // mmkn n7ot hena el usernaame
          // ),
          /*******************************/
          ListTile(
            leading: const Icon(
              Icons.person,
              size: 27,
            ),
            title: const Text(
              'Profile',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              // Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.garage,
              size: 27,
            ),
            title: const Text(
              'Garages Available',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              // Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.description,
              size: 27,
            ),
            title: const Text(
              'Current Bookings',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              // Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.history,
              size: 27,
            ),
            title: const Text(
              'Booking History',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              // Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.help,
              size: 27,
            ),
            title: const Text(
              'How it works',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              // Update the state of the app
              // ...
              // Then close the drawer
              // Navigator.pop(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.settings,
              size: 27,
            ),
            title: const Text(
              'Settings',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              _goToSettings(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.message,
              size: 27,
            ),
            title: const Text(
              'Contact Us',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              _goContactUs(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.notifications,
              size: 27,
            ),
            title: const Text(
              'Notifications',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {},
          ),
          ListTile(
            leading: const Icon(
              Icons.logout,
              size: 27,
            ),
            title: const Text(
              'Logout',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              _goToHome(context);
            },
          ),
          ListTile(
            leading: const Icon(
              Icons.exit_to_app,
              size: 27,
            ),
            title: const Text(
              'Exit',
              style: TextStyle(
                fontSize: 17,
                fontFamily: 'RalewayMedium',
              ),
            ),
            onTap: () {
              SystemNavigator.pop();
            },
          ),
        ],
      ),
    );
  }
}
