import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class ContactUS extends StatefulWidget {
  @override
  State<ContactUS> createState() => _ContactUSState();
}

class _ContactUSState extends State<ContactUS> {
  bool isAndroid = true;

  double screenWidth = 0;
  double screenHeight = 0;

  void initState() {
    isAndroid = (defaultTargetPlatform == TargetPlatform.android);
  }

  @override
  Widget build(BuildContext context) {
    setState(() {
      screenWidth = MediaQuery.of(context).size.width;
      screenHeight = MediaQuery.of(context).size.height;
    });
    return Scaffold(
      backgroundColor: Colors.orangeAccent,
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const SizedBox(
                  child: Image(
                    width: 100,
                    //  fit: BoxFit.fitHeight,
                    image: AssetImage('images/f.png'),
                  ),
                ),
               
              ],
            ),
            Row(
              children: [
                const SizedBox(
                  child: Image(
                    width: 100,
                    //  fit: BoxFit.fitHeight,
                    image: AssetImage('images/t.png'),
                  ),
                ),
               
              ],
            ),
           
            Row(
              children: [
                const SizedBox(
                  child: Image(
                    width: 100,
                    //  fit: BoxFit.fitHeight,
                    image: AssetImage('images/w.png'),
                  ),
                ),
               
              ],
            ),
             Row(
              children: [
                const SizedBox(
                  child: Image(
                    width: 100,
                    height: 10,
                    // fit: BoxFit.fitHeight,
                    image: AssetImage('i.png'),
                  ),
                ),
               
              ],
            ),
          ],
        ),
      ),
    );
  }
}
