import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'Payment.dart';

void _goToPayment(BuildContext ctx) {
   Navigator.of(ctx).push(
    MaterialPageRoute(builder: (_) {
      return Payment();
    }),
  );
}
class Settings extends StatefulWidget {
  @override
  State<Settings> createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool isAndroid = true;

  double screenWidth = 0;
  double screenHeight = 0;

  void initState() {
    isAndroid = (defaultTargetPlatform == TargetPlatform.android);
  }

  @override
  Widget build(BuildContext context) {
    setState(() {
      screenWidth = MediaQuery.of(context).size.width;
      screenHeight = MediaQuery.of(context).size.height;
    });
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(
            height: 150,
            child: InkWell(
            onTap: () {
              //go to edit
            },
            child: Text('Edit profile'),
          ),          ),
          
          SizedBox(
            height: 200,
            child: InkWell(
            onTap: () {
              _goToPayment(context);
            },
            child: Text('Payment'),
          ),          )
          
        ]),
          ),
    );
  }
}
