import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class Payment extends StatefulWidget {
  @override
  State<Payment> createState() => _PaymentState();
}

class _PaymentState extends State<Payment> {
  bool isAndroid = true;

  double screenWidth = 0;
  double screenHeight = 0;

  void initState() {
    isAndroid = (defaultTargetPlatform == TargetPlatform.android);
  }

  @override
  Widget build(BuildContext context) {
    setState(() {
      screenWidth = MediaQuery.of(context).size.width;
      screenHeight = MediaQuery.of(context).size.height;
    });
    return Scaffold(
      backgroundColor: Colors.orangeAccent,
      body: SingleChildScrollView(
          child: Row(
        children: [
          const SizedBox(
            child: Image(
              width: 100,
              //  fit: BoxFit.fitHeight,
              image: AssetImage('images/cash.png'),
            ),
            
          ),
          const SizedBox(
                  child: Image(
                    width: 100,
                    //  fit: BoxFit.fitHeight,
                    image: AssetImage('images/credit.png'),
                  ),
                ),
               
        ],
      )),
    );
  }
}
