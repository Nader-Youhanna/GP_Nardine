import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'menu.dart';

// void _goToMenu(BuildContext ctx) {
//   Navigator.of(ctx).push(
//     MaterialPageRoute(builder: (_) {
//       return Menu();
//     }),
//   );
// }

///This is the login page
class Login extends StatefulWidget {
  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  bool _usernameIsEntered = false;
  bool _passwordIsEntered = false;
  String _username = '';
  String _password = '';

  double screenWidth = 0;
  double screenHeight = 0;

  void _goBack(BuildContext ctx) {
    Navigator.of(ctx).pop();
  }

  ///This is a navigation function that redirects to the enter password page
  // void _enterPassword(BuildContext ctx) {
  //   Navigator.of(ctx).push(
  //     MaterialPageRoute(builder: (_) {
  //       return EnterPasswordPage(email: _username);
  //     }),
  //   );
  // }

  // ///This is a navigation function that redirects to the forgot password page
  // void _forgotPassword(BuildContext ctx) {
  //   Navigator.of(ctx).push(
  //     MaterialPageRoute(builder: (_) {
  //       return ForgotPasswordPage();
  //     }),
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    setState(
      () {
        screenWidth = MediaQuery.of(context).size.width;
        screenHeight = MediaQuery.of(context).size.height;
      },
    );
    return Scaffold(
      backgroundColor: const Color(0xFFf8b323),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            const SizedBox(
              height: 50,
            ),
            Row(children: [
              IconButton(
                icon: const Icon(
                  Icons.arrow_back,
                  size: 29,
                ),
                onPressed: () {
                  _goBack(context);
                },
              ),
            ]),
            const SizedBox(
              height: 20,
            ),
            Row(
              children: [
                SizedBox(
                  width: screenWidth * 0.2,
                ),
                const Center(
                  child: Image(
                    //  fit: BoxFit.fitHeight,
                    image: AssetImage('images/logorakeny.PNG'),
                  ),
                ),
              ],
            ),
            SizedBox(height: screenHeight * 0.02),
            Row(
              children: [
                SizedBox(
                  width: screenWidth * 0.27,
                ),
                const Text(
                  'Welcome back!',
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontFamily: 'RalewayMedium',
                    fontSize: 25,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 104, 42, 0),
                  ),
                ),
              ],
            ),
            SizedBox(height: screenHeight * 0.05),
            SizedBox(
              width: screenWidth * 0.84,
              child: TextField(
                decoration: const InputDecoration(
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      width: 1.7,
                      color: Color.fromARGB(248, 199, 33, 4),
                    ),
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0xFF7b2e07),
                    ),
                  ),
                  hintText: 'Email',
                  hintStyle: TextStyle(
                    fontFamily: 'RalewayMedium',
                    color: Color(0xFF7b2e07),
                    fontSize: 17,
                  ),
                ),
                onChanged: (value) {
                  if (value.isNotEmpty) {
                    _username = value;
                    setState(() {
                      _usernameIsEntered = true;
                    });
                  }
                },
              ),
            ),
            SizedBox(height: screenHeight * 0.01),
            SizedBox(
              width: screenWidth * 0.84,
              child: TextField(
                decoration: const InputDecoration(
                  focusedBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      width: 1.7,
                      color: Color.fromARGB(248, 199, 33, 4),
                    ),
                  ),
                  hintText: 'Password',
                  hintStyle: TextStyle(
                    fontFamily: 'RalewayMedium',
                    color: Color(0xFF7b2e07),
                    fontSize: 17,
                  ),
                  enabledBorder: UnderlineInputBorder(
                    borderSide: BorderSide(
                      color: Color(0xFF7b2e07),
                    ),
                  ),
                ),
                onChanged: (value) {
                  if (value.isNotEmpty) {
                    _password = value;
                    setState(() {
                      _passwordIsEntered = true;
                    });
                  }
                },
              ),
            ),
            /***************************** */
            SizedBox(
              height: screenHeight * 0.21,
            ),
            const Divider(
              height: 2,
              thickness: 1.1,
              color: Color.fromARGB(255, 112, 38, 2),
            ),
            SizedBox(height: screenHeight * 0.007),
            Row(
              children: <Widget>[
                SizedBox(
                  width: screenHeight * (8 / 360),
                ),
                ElevatedButton(
                  onPressed: () {
                    //_forgotPassword(context);
                  },
                  style: ButtonStyle(
                    foregroundColor:
                        MaterialStateProperty.all<Color>(Colors.black),
                    backgroundColor: MaterialStateProperty.all<Color>(
                      const Color.fromARGB(255, 221, 190, 88),
                    ),
                    shape: MaterialStateProperty.all<StadiumBorder>(
                      const StadiumBorder(
                        side: BorderSide(
                          color: Color.fromARGB(255, 212, 155, 31),
                          width: 1,
                        ),
                      ),
                    ),
                  ),
                  child: const Text(
                    'Forgot Password?',
                    style: TextStyle(
                      fontFamily: 'RalewayMedium',
                    ),
                  ),
                ),
                //const SizedBox(width: 125),
                SizedBox(
                  width: screenWidth * 0.31,
                ),
                ElevatedButton(
                  onPressed: () {
                    //_enterPassword(context);
                    // _goToMenu(context);
                  },
                  style: (!(_passwordIsEntered && _usernameIsEntered))
                      ? ButtonStyle(
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.black),
                          backgroundColor: MaterialStateProperty.all<Color>(
                            const Color.fromARGB(255, 221, 190, 88),
                          ),
                          shape: MaterialStateProperty.all<StadiumBorder>(
                            const StadiumBorder(
                              side: BorderSide(
                                color: Color.fromARGB(255, 212, 155, 31),
                                width: 1,
                              ),
                            ),
                          ),
                        )
                      : ButtonStyle(
                          foregroundColor:
                              MaterialStateProperty.all<Color>(Colors.white),
                          backgroundColor: MaterialStateProperty.all<Color>(
                            const Color.fromARGB(255, 104, 42, 0),
                          ),
                          shape: MaterialStateProperty.all<StadiumBorder>(
                            const StadiumBorder(
                              side: BorderSide(
                                color: Color.fromARGB(255, 212, 155, 31),
                                width: 1,
                              ),
                            ),
                          ),
                        ),
                  child: const Text(
                    'Next',
                    style: TextStyle(
                      fontFamily: 'RalewayMedium',
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
