import 'menu.dart';
import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({Key? key}) : super(key: key);
  final String title = "Rakeny";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.orangeAccent,
      ),
      // backgroundColor: Colors.orangeAccent,
      body: const Center(
        child: Text('You are in!'),
      ),
      drawer: Menu(),
    );
  }
}
