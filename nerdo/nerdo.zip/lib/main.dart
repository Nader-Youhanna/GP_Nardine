import 'package:flutter/material.dart';
import 'home.dart';
import 'home_page.dart';

void main() {
  runApp(
    const MaterialApp(
      home: HomePage(),
    ),
  );
}
